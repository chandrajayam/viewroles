import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewroles',
  templateUrl: './viewroles.component.html',
  styleUrls: ['./viewroles.component.css']
})
export class ViewrolesComponent implements OnInit {
  roleValues:any;
  inflightRoleValues:any;
  constructor() { }

  ngOnInit(): void {
    console.log("&&&&&&&&&&&&&&&&&&&&&&&-------> ")
     this.roleValues = [{
      "Role_name":"Developer",
      "Role_owner":"Jaya",
      "Description":"Zscalar developer role",
      "Exp_date":"05/30/2021",
      "version":"1"      
    },
    {
      "Role_name":"Admin",
      "Role_owner":"Prapa",
      "Description":"Zoom Admin role",
      "Exp_date":"05/30/2023",
      "version":"2"            
    },
    {
      "Role_name":"WorkflowAdmin",
      "Role_owner":"Juli",
      "Description":"Jira Workflow role",
      "Exp_date":"05/30/2022",
      "version":"4"            
    }]
  
    this.inflightRoleValues =  [{
      "Role_owner_email":"jaya@gmail.com",
      "Requested_Role":"CMS Director",
      "Description":"CMS Director",
      "Role_Reqsted_Expires_On":"05/30/2021"    
    },
    {
      "Role_owner_email":"george@yahoo.com",
      "Requested_Role":"Okta Admin",
      "Description":"Admin for okta ",
      "Role_Reqsted_Expires_On":"09/30/2021"         
    },
    {
      "Role_owner_email":"pineyrun@hotmail.com",
      "Requested_Role":"pineyRun Park Admin",
      "Description":"Piney Run Park Administrator",
      "Role_Reqsted_Expires_On":"08/30/2021"            
    }]
  }

}
