import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewrolesComponent } from './viewroles/viewroles.component';
import { LayoutComponent } from './layout/layout.component';
import {NotFoundComponent} from './not-found/not-found.component';

export const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
        { 
          path: '', redirectTo: '/viewroles', pathMatch: 'full'
        },
        {
          path: 'viewroles', component: ViewrolesComponent 
          },
    ],
  },
  {
    path: '**',
    redirectTo: 'not-found',
  },
  {
    path: 'not-found',
    component: NotFoundComponent,
  },
];
 

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
