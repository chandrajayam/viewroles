import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  Data: Array<any> = [
    { name: 'Pear', value: 'pear' },
    { name: 'Plum', value: 'plum' },
    { name: 'Kiwi', value: 'kiwi' },
    { name: 'Apple', value: 'apple' },
    { name: 'Lime', value: 'lime' }
  ];
  form: FormGroup;
  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      checkArray: this.fb.array([])
    })
  }

   rolesData : any;

   ngOnInit() {
   this.rolesData =

   {
    name: 'Testing Roles',
    color: 'primary',
    subtasks: [
      {name: "Developer-Atlassian", completed: false, color: 'primary'},
      {name: "Slack-Admin", completed: false, color: 'accent'},
      {name: "Zscalar-Manager", completed: false, color: 'warn'}
    ]
  };


  }

  // onCheckboxChange(e) {
  //   const checkArray: FormArray = this.form.get('checkArray') as FormArray;
  
  //   // if (e.target.checked) {
  //   //   checkArray.push(new FormControl(e.target.value));
  //   // } else {
  //   //   let i: number = 0;
  //   //   checkArray.controls.forEach((item: FormControl) => {
  //   //     if (item.value == e.target.value) {
  //   //       checkArray.removeAt(i);
  //   //       return;
  //   //     }
  //   //     i++;
  //   //   });
  //   // }
  // }
}
